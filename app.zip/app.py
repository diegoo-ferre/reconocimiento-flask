
from flask import Flask, request, jsonify
from flask_cors import CORS
import base64
import numpy as np
import cv2
import face_recognition
import psycopg2

app = Flask(__name__)
CORS(app)

# 🔹 función de conexión segura
def get_connection():
    return psycopg2.connect(
        host="dpg-d722t9p4tr6s739f73ag-a.oregon-postgres.render.com",
        database="biometrico_ytr7",
        user="biometrico_ytr7_user",
        password="kV68XNGBKHeMYUF8hX0fpS2hUueDUI0p"
    )


@app.route('/reconocer', methods=['POST'])
def reconocer():
    try:
        data = request.get_json()
        foto_base64 = data['foto'].split(',')[1]

        imagen = base64.b64decode(foto_base64)
        np_arr = np.frombuffer(imagen, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        rostros = face_recognition.face_locations(rgb)
        if len(rostros) == 0:
            return jsonify({"resultado": "sin_rostro"})

        encoding_actual = face_recognition.face_encodings(rgb, rostros)[0]

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT id, nombre, foto1 FROM personas")
        personas = cursor.fetchall()

        cursor.close()
        conn.close()

        for p in personas:
            id_persona, nombre, foto_db = p

            if foto_db is None:
                continue

            try:
                imagen_db = base64.b64decode(foto_db.split(',')[1])
                np_arr_db = np.frombuffer(imagen_db, np.uint8)
                img_db = cv2.imdecode(np_arr_db, cv2.IMREAD_COLOR)

                rgb_db = cv2.cvtColor(img_db, cv2.COLOR_BGR2RGB)

                encodings_db = face_recognition.face_encodings(rgb_db)
                if len(encodings_db) == 0:
                    continue

                resultado = face_recognition.compare_faces([encodings_db[0]], encoding_actual)

                if resultado[0]:
                    return jsonify({
                        "resultado": "permitido",
                        "persona_id": id_persona,
                        "nombre": nombre
                    })

            except:
                continue

        return jsonify({"resultado": "denegado"})

    except Exception as e:
        return jsonify({"resultado": "error", "mensaje": str(e)})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)